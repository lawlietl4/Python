from ImageConverter import *

imageConvert = imageConverter()

imageConvert.imgConvert()
