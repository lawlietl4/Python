from bankAccount import*

balance = 100
accountNum = 981028347890

account = BankAccount(accountNum, balance)
print(f'${account.balance}')

account.deposit(50)
print(f'${account.balance}')

account.withdraw(25)
print(f'${account.balance}')

account.deposit(30)
print(f'${account.balance}')

account.withdraw(200)
print(f'${account.balance}')
