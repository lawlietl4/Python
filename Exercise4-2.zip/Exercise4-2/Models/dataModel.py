import psycopg2


class dataMod():
    def __init__(self):
        self.connection = psycopg2.connect(host='localhost', port='5432',
                                           user='Guest', password='1234', database='banking')  # credentials and the database to aim at in the postgreSQL server
        self.connection.autocommit = True
        self.cursor = self.connection.cursor()


class DbCustomer(dataMod):
    def createTable(self):
        createTableCom = """
                CREATE TABLE customers (
                    id SERIAL NOT NULL PRIMARY KEY,
                    email varchar(50) NOT NULL,
                    password varchar(60) NOT NULL,
                    first_name varchar(20) NOT NULL,
                    lsat_name varchar(20) NOT NULL
                );
            """
        self.cursor.execute(createTableCom)
        # self.cursor.close()
        # self.connection.close()

    def insert(self, email, password, firstName, lastName):
        statement = f"""
            INSERT INTO customers (
                email,
                password,
                first_name,
                lsat_name
            )
            VALUES(
                '{email}',
                '{password}',
                '{firstName}',
                '{lastName}'
            );
        """
        self.cursor.execute(statement)
        self.cursor.close()
        self.connection.close()
    def login(self, username,password):
        self.password = ''
        self.username = ''
        self.connection = psycopg2.connect(host='localhost', port='5432',
                                           user=username, password=password, database='banking')
