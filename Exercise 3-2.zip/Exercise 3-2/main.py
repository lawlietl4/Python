from bankAccount import*

balance = 100
accountNum = 981028347890

account = CheckingAccount(accountNum, balance)

account.__init__
account.withdraw(80)

account.deposit(30)
print(account)
