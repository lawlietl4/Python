import sys

from Models.dataModel import *

customer = DbCustomer()
try:
    customer.createTable()
    
except:
    if sys.argv[1] == '-r':
        first_name = input('what name are you registering? ')
        last_name = input("what's the client's last name? ")
        email = input('The client email ')
        password = input('what is the password to associate with the user? ')
        customer.insert(email, password, first_name, last_name)

    print('done')
